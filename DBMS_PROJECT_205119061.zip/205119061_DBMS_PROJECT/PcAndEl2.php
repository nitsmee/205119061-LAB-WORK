<?php
		session_start();
		if (!isset($_SESSION['name'])) {
    header("Location: expiredS.php");
    exit;
		}
?>
<html style="background-color:#EAEDED">
<head>
<title>
		Pc and El2</title>
		<link rel="shortcut icon" href="Logo.png" type="image/x-icon">
<style>
a:hover{
			font-weight:bolder;
			color:Tan;
		}
		body{
			margin:0;
		}
a{
		
		font-size:18px;
		text-decoration:none;
		font-weight:bolder;
}
p.cl1{
	font-size:22px;
	color:blue;
	font-weight:bolder;
}
div{
		
	}
	.pagination a {
  color: black;
  float:none;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
}
body{
			margin:0;
		}
.pagination a.active {
  background-color: dodgerblue;
  color: white;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
</head>
<body>
<div style=" height:230px; background-color:#192537;">
<a href="homepage.php" ><img src="toplogo.jpg"/></a>
</div>
</br>
</br>
<div style="background-color:white;float:left; margin-bottom:80px; margin-left:100px;  width:450px; " >
<img src="tstr1.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a target="_blank" href="https://www.amazon.in/V-Guard-Pop-Up-Toaster-Removable-Collection/dp/B081K2CJ64/ref=redir_mobile_desktop?ie=UTF8&aaxitk=3raoWF8zrUnnZQSIYbFcNQ&hsa_cr_id=4509334890802&ref_=sb_s_sparkle" >V-Guard VT210 2 Slice Pop-Up Toaster with Removable Crumb Collection Tray (800 Watts, Black)r</a>
	</br>
	<span><b>by V-Guard</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 2,030.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 1,445.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">585.00Rs ( 29% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.3 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white; margin-bottom:80px; float:left; margin-left:200px;  width:450px; " >
<img src="prsckr5.jpg" width="300px" height="250px"/>
	</br>
	<p class="cl1">Flipcart.com</p>
	<a target="_blank" href="https://www.flipkart.com/butterfly-friendly-3-l-induction-bottom-pressure-cooker/p/itmf84zrn2j4sqkh?pid=PRCF84ZRSRCS5HHC&lid=LSTPRCF84ZRSRCS5HHCV2WVV7&marketplace=FLIPKART&spotlightTagId=BestvalueId_upp%2Ftnx%2Fgsl&srno=b_1_6&otracker=browse&fm=organic&iid=6e7cdb31-7a1c-4f85-a44e-dd537f00ea90.PRCF84ZRSRCS5HHC.SEARCH&ppt=browse&ppn=browse&ssid=3z51y1zojk0000001584537476085" >Butterfly Friendly 3 L Induction Bottom Pressure Cooker  (Aluminium).</a>
	</br>
	<span><b>by ButterFly</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 1,199.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 500.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"> 50% OFF</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.1 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>

<div style="background-color:white; margin-bottom:80px; float:left; margin-left:100px;  width:450px;" >
<img src="prsckr5.jpg" width="300px" height="250px"/>
	</br>
	<p class="cl1">Flipcart.com</p>
	<a target="_blank" href="https://www.flipkart.com/butterfly-friendly-3-l-induction-bottom-pressure-cooker/p/itmf84zrn2j4sqkh?pid=PRCF84ZRSRCS5HHC&lid=LSTPRCF84ZRSRCS5HHCV2WVV7&marketplace=FLIPKART&spotlightTagId=BestvalueId_upp%2Ftnx%2Fgsl&srno=b_1_6&otracker=browse&fm=organic&iid=6e7cdb31-7a1c-4f85-a44e-dd537f00ea90.PRCF84ZRSRCS5HHC.SEARCH&ppt=browse&ppn=browse&ssid=3z51y1zojk0000001584537476085" >Butterfly Friendly 3 L Induction Bottom Pressure Cooker  (Aluminium).</a>
	</br>
	<span><b>by ButterFly</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 1,199.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 500.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"> 50% OFF</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.1 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>

</div>	
<div style="background-color:white;  margin-bottom:80px;float:left; margin-left:200px;  width:450px;" >
<img src="gas2.jpeg" width="400px" height="280px"/>
	</br>
	<p class="cl1">Flipcart.com</p>
	<a target="_blank" href="https://www.flipkart.com/prestige-pearl-aluminium-manual-gas-stove/p/itme9f0342c36fdd?pid=GSTFGMADQZKVKGS9&lid=LSTGSTFGMADQZKVKGS9L6O2BZ&marketplace=FLIPKART&srno=s_1_11&otracker=search&otracker1=search&fm=organic&iid=275e746e-f13a-4d4f-9c3a-049c33464ff2.GSTFGMADQZKVKGS9.SEARCH&ppt=sp&ppn=sp&ssid=paezxbop5c0000001584726921311&qH=674d08eaa84e53e7" >Prestige Pearl Aluminium Manual Gas Stove  (3 Burners)</a>
	<span><b>by Prestige</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 6000.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 3499.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"> 41% OFF</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.3 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white; margin-bottom:80px; float:left; margin-left:100px; width:450px;" >
<img src="mxr1.jpeg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Flipcart.com</p>
	<a target="_blank" href="https://www.flipkart.com/philips-hl7710-00-600-w-mixer-grinder/p/itmd348713beed49?pid=MIXDS8RHY9R7GP5Q&lid=LSTMIXDS8RHY9R7GP5QWDDCR9&marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm=SEARCH&iid=en_WN64IP9%2Fwz8kfYVAY7QzUXzfePSHBdCeXE%2F5AXyIYEB2pnTjLF0gWWRGRV2mnAbnDRZc6tpL7QzS4cEeSkVOVg%3D%3D&ppt=sp&ppn=sp&ssid=gz3ewlzi000000001584727325309&qH=54541c4cd654dce7" >Philips HL7710 /00 600 W Mixer Grinder  (Red, White, 3 Jars).</a>
	</br>
	<span><b>by Philips</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 3955.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 3155.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"> 20% OFF + Extra 144 Rs. OFF</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.3 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white; margin-bottom:80px; float:left; margin-left:200px; width:450px;" >
<img src="jc1.jpeg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Flipcart.com</p>
	<a target="_blank" href="https://www.flipkart.com/tom-gee-j-01-fruit-vegetable-mixer-hand-juicer-0/p/itm4993323ec6b7d?pid=MIXFACSTABT82UGD&lid=LSTMIXFACSTABT82UGDMDTPTB&marketplace=FLIPKART&spotlightTagId=TrendingId_j9e%2Fm38%2F7ek&srno=s_1_1&otracker=AS_QueryStore_OrganicAutoSuggest_2_5_na_na_na&otracker1=AS_QueryStore_OrganicAutoSuggest_2_5_na_na_na&fm=SEARCH&iid=31fc169b-5d88-4110-9b70-1c1c58ddf9f6.MIXFACSTABT82UGD.SEARCH&ppt=sp&ppn=sp&ssid=oaetlcq0gw0000001587563656352&qH=e2a1630a85d2e433" >Tom & Gee J 01 Fruit And Vegetable Mixer Hand Juicer 0 Juicer  (Green, 1 Jar).</a>
	</br>
	<span><b>by Tom & Gee</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 999.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 425.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"> 57% OFF</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 3.8 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
</body>
</html>