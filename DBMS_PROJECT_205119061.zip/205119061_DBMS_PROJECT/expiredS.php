<html>
<head>
<style>
a{
	color:light-blue;
	text-decoration:none;
	font-family:Arial,sans-serif;
}
a:hover{
		font-weight:bolder;
		 color:voilet;
}
</style>
</head>
<body>
<img src="session_expired.png" style="margin:200 400 30;"/>
<span style=" margin:100 420 300; font-family:Arial,sans-serif;">Click <a href="login_page.html">here</a> to start a new session.</span>
</body>
</html>