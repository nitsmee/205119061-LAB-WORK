<html>
<head>
    <title></title>
    <meta http-equiv="refresh" content="5; url=">
</head>
<body>
    <h3>
        In 5 seconds this web page will be redirect to "Dotnet Learners" website....</h3>
</body>
</html>