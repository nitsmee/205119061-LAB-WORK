<?php
		session_start();
		if (!isset($_SESSION['name'])) {
    header("Location: expiredS.php");
    exit;
		}
		
?>
<html style="background-color: #EAEDED">
<head>
<title>
		Pc and El1</title>
		<link rel="shortcut icon" href="Logo.png" type="image/x-icon">
<style>
a:hover{
			font-weight:bolder;
			color:Tan;
		}
		body{
			margin:0;
		}
a{
		
		font-size:18px;
		text-decoration:none;
		font-weight:bolder;
}
p.cl1{
	font-size:22px;
	color:blue;
	font-weight:bolder;
}
div{
		
	}
	.pagination a {
  color: black;
  float:none;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
}
body{
			margin:0;
		}
.pagination a.active {
  background-color: dodgerblue;
  color: white;
}

.pagination a:hover:not(.active) {background-color: #ddd;}
</style>
</head>
<body>
<div style=" height:230px; background-color:#192537;">
<a href="homepage.php" ><img src="toplogo.jpg"/></a>
</div>
</br>
</br>
<div style="background-color:white; float:left; margin-bottom:80px; margin-left:100px; width:450px;" >
<img src="prsckr2.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a target="_blank" href="https://www.amazon.in/Prestige-Stainless-Pressure-Cooker-Litres/dp/B01684ONUY/ref=redir_mobile_desktop?ie=UTF8&aaxitk=mtadU.aS97-5YokLcud3tw&hsa_cr_id=9685267400302&ref_=sb_s_sparkle" >Prestige Clip On Stainless Steel Pressure Cooker with Glass Lid, 3 Litres, Silver</a>
	</br>
	<span><b>by Prestige</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 3,780.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 3,370.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">410.00Rs ( 11% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 3.4 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</br></span>
</div>	
<div style="background-color:white; float:left; margin-bottom:80px; margin-left:200px; width:450px;" >
<img src="prsckr3.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a target="_blank" href="https://www.amazon.in/Prestige-Aluminium-Pressure-2-Pieces-Charcoal/dp/B01684OL4C/ref=redir_mobile_desktop?ie=UTF8&aaxitk=mtadU.aS97-5YokLcud3tw&hsa_cr_id=9685267400302&ref_=sb_s_sparkle" >Prestige Clip On Aluminium Pressure Cooker with Glass Lid, 3 Litres, 2-Pieces, Charcoal Black.</a>
	</br>
	<span><b>by Prestige</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 3,730.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 2,799.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">931.00Rs ( 25% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 3.6 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white;  float:left; margin-bottom:80px;margin-left:100px; width:450px;" >
<img src="prsckr4.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a  target="_blank" href="https://www.amazon.in/Prestige-Stainless-Pressure-Cooker-Metallic/dp/B01684OKYS/ref=redir_mobile_desktop?ie=UTF8&aaxitk=mtadU.aS97-5YokLcud3tw&hsa_cr_id=9685267400302&ref_=sb_s_sparkle" >Prestige Clip On Stainless Steel Pressure Cooker with Glass Lid (5 Litres, Set of 2, Metallic Silver).</a>
	</br>
	<span><b>by Prestige</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 4,070.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 3,595.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">475.00Rs ( 12% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 3.8 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white; float:left; margin-left:200px; margin-bottom:80px; width:450px;" >
<img src="tstr2.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a target="_blank" href="https://www.amazon.in/Philips-Collection-HD2582-00-830-Watt/dp/B071VNHMX2/ref=pd_sbs_79_1/257-0942655-5571659?_encoding=UTF8&pd_rd_i=B071VNHMX2&pd_rd_r=96a65689-1b8d-4a54-93b5-53e17cbdc06a&pd_rd_w=uJQTx&pd_rd_wg=p94md&pf_rd_p=fbf43daf-8fb3-47b5-9deb-ae9cce3969a9&pf_rd_r=VYNT6MKA72K9JAT4PNFK&psc=1&refRID=VYNT6MKA72K9JAT4PNFK" >Philips Daily Collection HD2582/00 830-Watt 2-Slice Pop-up Toaster (White).</a>
	</br>
	<span><b>by Philips</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 1,995.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 1,787.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">208.00Rs ( 10% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4.4 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>s
</div>	
<div style="background-color:white;  float:left; margin-left:100px; margin-bottom:80px; width:450px; " >
<img src="gas1.jpg" width="250px" height="250px"/>
	</br>
	<p class="cl1">Amazon.in</p>
	<a  target="_blank" href="https://www.amazon.in/Cello-Prima-Stove-Burner-Certified/dp/B07X55RJFD/ref=redir_mobile_desktop?ie=UTF8&aaxitk=Nfhiqj6ay7jBfN90kOokqg&hsa_cr_id=4781922800602&ref_=sb_s_sparkle" >Cello Prima Gas Stove 3 Burner Glass Top, Black, ISI Certified.</a>
	</br>
	<span><b>by Cello</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> 6,999.00Rs</span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> 2,969.00Rs</span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;">4030.00Rs ( 58% OFF)</span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
<div style="background-color:white;  float:left; margin-left:200px; margin-bottom:80px; width:450px; " >
<img src="mxr2.jpg" width="300px" height="300px"/>
	</br>
	<p class="cl1">Amazon.com</p>
	<a target="_blank" href="https://www.amazon.in/Philips-HL7756-00-750-Watt-Grinder/dp/B01GZSQJPA/ref=sr_1_1?crid=OB961GLE5AVN&dchild=1&keywords=mixer+grinder+philips&qid=1587562850&sprefix=mixer%2Caps%2C423&sr=8-1" >Philips HL7756/00 750-Watt Mixer Grinder with 3 Jars (Black).</a>
	<span><b>by Philips</b></span>
	</br>
	<span><b>M.R.P:<span style="text-decoration:line-through;"> </span></span>
	</br>
	<span><b>Price:<span style="color:brown; font-size:23px;"> </span></span>
	</br>
	<span><b>Your Save: <span style="color:brown;"></span></span>
	</br>
	<span>&nbsp &nbsp &nbsp &nbspInclusive of all Taxes.</span>
	</br>
	<span><b>Rating:<span style="color:yellow; background-color:black; font-size:20px;">&nbsp 4 Out Of 5&nbsp</span></span>
	</br>
	<span style="color:green; font-size:20px; font-family:Arial,serif;">&nbsp &nbsp &nbsp &nbsp In Stock.</span>
</div>	
</body>
</html>