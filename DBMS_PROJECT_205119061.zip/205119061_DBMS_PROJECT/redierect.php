<html>
<head>
    <title></title>
    <meta http-equiv="refresh" content="7; url='orderSuccess.php'">
</head>
<body>
<h2> Don't close your window  in few seconds you will be redierected to Our Payment Page...</h2>
    <div style="margin:200 200 200 400;">
	<h3>Payment Processsing ...</h3>
	<img src="processing1.gif"/>
	</div>
</body>
</html>